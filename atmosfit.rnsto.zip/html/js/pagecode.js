// VARIABLES

// FUNCTIONS
$(".js-toggle-burger").click(function(){
    $(".burger-icon").toggleClass("active");
    $(".full-navigation").toggleClass("active");
    //$(".full-navigation").slideToggle();
});
$('input[type="radio"]').click(function(){
    var demovalue = $(this).val(); 
    $("div.detail-item").hide();
    $("#item-"+demovalue).show();
});
$('.js-acc-trigger').click(function(){
    $(this).next('.js-acc-content').toggleClass('active');
    //$(this).next('.js-acc-content').slideToggle('500');
    $(this).find('i').toggleClass('fa-angle-down fa-angle-up')
});
$(".js-modal--close").click(function(){
  $(".modal-window").hide();
});
function invoiceFunction() {
    // Get the checkbox
    var checkBox = document.getElementById("checkInvoice");
    // Get the output text
    var invData = document.getElementById("invoiceData");
  
    // If the checkbox is checked, display the output text
    if (checkBox.checked == true){
      invData.style.display = "block";
    } else {
      invData.style.display = "none";
    }
  }
function termsFunction() {
  var checkTerms = document.getElementById("checkTerms");
  var subTermsV = document.getElementById("submitTerms");  
  if (checkTerms.checked == true){
    subTermsV.style.backgroundColor = "#0E5B78";
    subTermsV.style.pointerEvents = "initial";
    subTermsV.style.borderColor = "#0E5B78";
  } else {
    subTermsV.style.pointerEvents = "none";
    subTermsV.style.backgroundColor = "#969696";
    subTermsV.style.borderColor = "#969696";
  }
}
$('a[href^="#"]').on('click', function (e) {
    e.preventDefault();
 
    var targetEle = this.hash;
    var $targetEle = $(targetEle);
 
    $('html, body').stop().animate({
        'scrollTop': $targetEle.offset().top
    }, 800, 'swing', function () {
        window.location.hash = targetEle;
    });
});
/*$('input:checkbox').change(function(){
    if($(this).is(":checked")) {
        $('div.menuitem').addClass("menuitemshow");
    } else {
        $('div.menuitem').removeClass("menuitemshow");
    }
});*/
    
function responsive(){
}

function start(){
    
}
// INVOKE
$(document).on('ready', start);
$(window).on('load resize', responsive);

