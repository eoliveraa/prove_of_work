<?php include "header.php"; ?>

<!-- YOUR HTML HERE -->
    <!-- primer version-->
    <section class="hero-banner container-fluid">
        <article class="banner-content overlay--1">
            <div class="container">
          
                    <div class="heading col-sm-12 col-md-6 col-lg-6 offset-md-3 offset-lg-3 ">
                        <h1>Entrenamiento en altura</h1>
                    </div>
              
                    <div class="subheader col-sm-12 col-md-6 col-lg-6 offset-md-3 offset-lg-3">
                        <h2>Máximo rendimiento en menos tiempo</h2>
                        <a href="#que-es-atmosfit" class="button ghost--button">Descubre como</a>
                    </div>  
                
            </div>
                      
        </article>
    </section>

    <section class="value-cta" id="que-es-atmosfit">
        <article class="content container">
            <div class="col-sm-12 col-md-8 col-lg-8 offset-md-2 offset-lg-2">
                <h3>¿Qué es atmosfit?</h3>
                <p>Atmosfit es el entrenamiento que consiste en simular la altura del entorno con el fin de aumentar el rendimiento físico del cuerpo humano, ayudando al transporte y uso de oxígeno y mejorando función muscular.</p>
                <p>Con Atmosfit puede obtener los beneficios del entrenamiento de altura sin importar en qué parte del mundo se encuentre.</p>  
                <p>Aumenta la resistencia de tu cuerpo con altura simulada generando adaptaciones corporales</p>
                <h3>Obtén resultados desde la primer semana</h3>
                <a class="button primary-button" href="reservar.php">Reservar ahora</a>
            </div>
        </article>
    </section>
    <div class="basic-headings container">
        <h4>Reserva tu entrenamiento</h4>
    </div>
    <?php include "booking-module.php"; ?>
    <div class="basic-headings container">
        <h3 class="headshot-copy col-sm-12 col-md-12 col-lg-12">
            Entrenamiento a más de 3,200 M.S.N.M. Diseñado para deportistas de alto rendimiento.
        </h3>
    </div>
    <?php include "plan-selection-module.php"; ?>
<?php include "footer.php"; ?>
