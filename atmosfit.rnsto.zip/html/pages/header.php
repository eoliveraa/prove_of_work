<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Atmosfit - Enrenamiento con altura simulada para atletas de alto rendimiento</title>

    <!-- VIEWPORT -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">

    <!-- MOBILE FORMAT -->
    <meta name="format-detection" content="telephone=no">
    <meta name="theme-color" content="#0E5B78">

    <!-- DESCRIPTION & KEYWORDS -->
    <meta name="description" content="Aumenta la resistencia de tu cuerpo con entrenamiento en altura simulada generando adaptaciones corporales">
    <meta name="keywords" content="Aumenta la resistencia, cuerpo, entrenamiento, altura simulada, adaptaciones corporales, atmosfit, presion, 5000 msnm, 3200 msnm, monterrey, mty, centro monterrey, ironman, triatlon, sesiones" />
    

    <!-- AUTHOR & SITEMAP -->
    <link rel="author" type="text/plain" href="humans.txt">
    <link rel="sitemap" type="application/xml" title="Sitemap" href="sitemap.xml">

    <!-- ICON -->
    <link rel="shortcut icon" type="image/x-icon" href="../img/brand/favicon.ico">
    <link rel="shortcut icon" type="image/png" href="../img/brand/favicon.png">
    <link rel="apple-touch-icon" href="../img/brand/favicon.png">
    <meta property="og:url" content="https://www.atmosfit.com" />
    <meta property="og:image" content="https://atmosfit.com/img/brand/favicon.png" />
    <!-- CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Red+Hat+Display:400,400i,700,700i&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/ionicons@4.5.10-0/dist/css/ionicons.min.css" rel="stylesheet">

    <link rel="stylesheet" href="../css/styles.min.css">
    <!--link href="https://fonts.googleapis.com/css?family=Roboto:400,400i,500,500i&display=swap" rel="stylesheet"-->
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
    <!--link rel="stylesheet" type="text/css" href="../plugins/pickdate/themes/classic.css"/-->
    <link rel="stylesheet" type="text/css" href="../css/jquery.datetimepicker.css">
</head>
<body>
    <div id="fb-root"></div>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v4.0"></script>

    <!-- INICIA HEADER CENTRADO -->
    <header class="top-header">
        <nav class="navigation nav--mobile mobile-only container">
            <ul class="main-menu">
                <li class="burger-menu js-toggle-burger">
                    <figure class="burger-icon">
                         <img src="../img/burger.svg" />                           
                    </figure>
                </li>
                <li class="reflogo">
                    <a href="index.php">
                        <figure class="reflogo--image">
                            <img src="../img/brand/atmosfit--white.svg" />
                        </figure>
                    </a>
                </li>
                <li class="call-to-action">
                    <a href="reservar.php" class="button highlight">Reservar</a>
                </li>
            </ul>
            <ul class="full-navigation">
                <li><a href="#">¿Qué es ATMOSFIT?</a></li>
                <li><a href="iniciar-sesion.php">Iniciar sesión</a></li>
                <li><a href="reservar.php">Reservar sesiones</a></li>
                <li><a href="#">Aviso de privacidad</a></li>
                <li><a href="#">Términos y condiciones</a></li>
            </ul>
        </nav>
        <nav class="navigation nav--desktop desktop-only container">
            <ul class="desktop-menu">
                <li class="reflogo">
                    <a href="index.php">
                        <figure class="reflogo--image">
                            <img src="../img/brand/atmosfit--white.svg" />
                        </figure>
                    </a>
                </li>
                <li class="call-to-action">
                    <a href="reservar.php" class="button highlight">Reservar</a>
                </li>
                <li><a href="iniciar-sesion.php">Iniciar sesión</a></li>
                <li><a href="index.php">¿Qué es ATMOSFIT?</a></li>

            </ul>
        
        </nav>
    </header>
    <!-- TERMINA HEADER CENTRADO MOBILE -->