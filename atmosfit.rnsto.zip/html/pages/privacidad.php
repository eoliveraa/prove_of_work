<?php include "header.php"; ?>

<!-- YOUR HTML HERE -->
<section class="internal-pages container">
        <!--div class="go-back">
            <a href="index.php"><i class="fa fa-chevron-left"></i></a>
        </div-->
        
        <article class="row">
            <div class="col-sm-12 col-md-8 col-lg-8 offset-md-2 offset-lg-2">
                <h1>ATMOS HYPOXICO, S.A. DE C.V. </h1>
                <h2>AVISO DE PRIVACIDAD</h2>
                <p>En cumplimiento con lo establecido en los artículos 15, 16, 17,18 y demás correlativos de la Ley Federal de Protección de Datos Personales en Posesión de Particulares publicada en el Diario Oficial de la Federación el día 5 de Julio de 2010 y vigente a partir del 6 de Julio de 2010 (la “Ley”), se extiende el presente Aviso de Privacidad.</p>
                <h3>I.- Responsable del Tratamiento de Datos Personales.</h3>
                <p>El responsable del uso y protección de sus datos personales es 1 Atmos Hypoxico, S.A. de C.V.   (Denominado en lo sucesivo el “Responsable”), cuyas oficinas se encuentran ubicadas en Ave. Roberto Garza Sada 101, local 305, Col Carrizalejo, San Pedro Garza García, NL , y quien por medio del presente hace de su conocimiento que los datos personales que se pretenden recabar de Usted como titular de los mismos (en lo sucesivo el “Titular”), serán tratados estrictamente para los fines detallados en el presente documento.</p>
                <h3>II.- Finalidad del tratamiento de los datos personales.</h3>
                <p>El Responsable, para la consecución de su objeto social y en particular para estar en condiciones de ofrecer y prestar un mejor servicio a sus clientes, requiere datos personales de personas físicas, o bien, de personas morales de las que requiere datos personales de sus representantes o accionistas.</p>
                <p>Dichos datos personales, serán tratados estrictamente para alcanzar las siguientes finalidades :</p>
                <ul>
                    <li>Confirmar su identidad.</li>
                    <li>Integración de base de datos de clientes.</li>
                    <li>Elaborar comprobantes fiscales.</li>
                    <li>Realizar la facturación electrónica.</li>
                    <li>Dar cumplimiento a los requerimientos hechos por las autoridades, cuando sea necesario para salvaguardar el interés público.</li>
                    <li>Presentar declaraciones de impuestos ante el Servicio de Administración</li>
                    <li>Tributaria (SAT) y ante la Secretaría de Hacienda y Crédito Público (SHCP).</li>
                    <li>La negociación, cumplimiento y terminación de la relación jurídica entre el</li>
                    <h4>Responsable y el Titular.</h4>
                    <li>La gestión, administración y prestación de servicios proporcionados por el Responsable</li>
                    <li>Para efectos de dar información a despachos que realizan auditorías.
                    <li>Atender quejas y/o reclamaciones.</li>
                    <li>Realizar o modificar los contratos entre el Titular y clientes.</li>
                    <li>Realizar encuestas de servicio y calidad, así como ofrecer o promover productos propios o de terceros.
                        Elaborar estadísticas y reportes de los servicios prestados por el Responsable con el objeto de llevar un control interno de dichos servicios así como para dar seguimiento puntual de los mismos.</li>
                
                </ul>


                <h3>-III.- Datos personales que se recaban </h3>
                <p>Los datos personales que el Responsable recaba son:</p>
                <ol>
                    <li>Nombre completo;</li>
                    <li>Domicilio;</li>
                    <li>Calle;</li>
                    <li>Número;</li>
                    <li>Colonia;</li>
                    <li>Código Postal;</li>
                    <li>Ciudad;</li>
                    <li>Estado;</li>
                    <li>Correo electrónico;</li>
                    <li>Número telefónico fijo y celular;</li>
                    <li>Registro Federal de Contribuyentes (RFC).</li>
                </ol>
                <h3>IV.- Opciones y medios que el Responsable ofrece para limitar el uso o divulgación de datos personales.</h3>
                <p>Con el objeto de limitar el uso o divulgación de los datos personales, el Responsable resguarda dichos datos personales bajo programas de cómputo con acceso limitado mediante el uso de contraseñas con altas especificaciones de seguridad, únicamente a personas que, con motivo de sus funciones, se le otorgan facultades para ello.</p>
                <p>Tanto en el caso de datos personales contenidos en medios electrónicos como en documentos físicos, el Responsable utiliza las mismas medidas de seguridad que las que aplica en su propia información.</p>
                <p>Asimismo, el Responsable obtiene del personal que por sus funciones tiene acceso a los datos personales, convenios, acuerdos u obligación de confidencialidad, contemplando que los datos personales es información confidencial y por tanto, en caso de divulgar dicha información confidencial se hará acreedor a las sanciones civiles y penales que en su caso procedan.</p>
                <p>Finalmente, el Responsable ha implementado políticas y procesos internos aplicables a su personal, a través de los cuales los datos personales son utilizados por un mínimo de personas, limitándose el uso de los medios de reproducción, y generándose la obligación de destruir todas aquellas copias o reproducciones de documentos que contengan datos personales que no sean estrictamente indispensables para el adecuado desempeño de las funciones del personal del Responsable, así como la prohibición de extraer de las oficinas del Responsable cualquier tipo de información que contenga datos personales.</p>
                <h3>V.- Medios para ejercer los derechos de acceso, rectificación, cancelación u oposición (ARCO).</h3>
                <p>Los Titulares tienen derecho a conocer cuáles son los datos personales que tenemos, para que los usamos y las condiciones de uso que les brindamos (Acceso), tienen derecho a solicitar la corrección de su información personal en caso de que ésta se encuentre inexacta (Rectificación); que la eliminemos de nuestras bases de datos cuando considere que los datos no están siendo utilizado conforme a los principios, deberes y obligaciones previstas en la normativa (Cancelación); y también a oponerse al uso de sus datos personales para fines específicos (Oposición). Este conjunto de derechos se conoce como Derechos ARCO. </p>
                <p>Usted puede revocar el consentimiento, que, en su caso, nos haya otorgado para el tratamiento de sus datos personales. Sin embargo, es importante que tenga en cuenta que no en todos los casos podremos atender a su solicitud o concluir el uso de forma inmediata, ya que es posible que por alguna obligación legal requiramos seguir tratando sus datos personales. Además, deberá de considerar que, para ciertos fines, la revocación del procedimiento implique que ya no podamos seguir prestándole el servicio que solicitó, o que concluya su relación con nosotros.</p>
                <p>Los Titulares de datos personales que el Responsable trate, podrán ejercer los derechos ARCO, mediante una solicitud por escrito que deberá ser presentada físicamente en las oficinas del Responsable ubicadas en el domicilio señalado con anterioridad o al correo info@atmosfit.com </p>
                <h4>La solicitud de derechos ARCO deberá contener y acompañar lo que señala la Ley en su artículo 29, tal como:</h4>
                <ul>
                    <li>El nombre y domicilio del Titular u otro medio para comunicarle la respuesta a su solicitud</li>
                    <li>Los documentos que acrediten su identidad o, en su caso, la representación legal del Titular.</li>
                    <li>La descripción clara y precisa de los datos personales respecto de los que se busca ejercer alguno de los derechos.</li>
                    <li>Cualquier otro elemento o documento que facilite la localización de los datos personales, así como cualquier otro documento que exija la legislación vigente al momento de la presentación de la solicitud.</li>
                </ul>
                <p>Presentada la solicitud el Responsable la procesará conforme a lo establecido en la Ley, debiendo pagar el Titular al Responsable los gastos de envío o reproducción de los datos personales, así como una cantidad equivalente a tres días de salario mínimo general vigente en el Distrito Federal, cuando una misma persona reitere una solicitud en un periodo menor a doce meses y con las excepciones que señale la Ley.</p>
                <p>La revocación del consentimiento que pretendiera realizar el Titular de los datos personales deberá hacerlo por el mismo medio que si se tratara de los derechos citados en la primera parte del presente apartado y se sujetará al procedimiento que para ellos prevé la Ley.</p>
                <h3>VI.- Limitación de uso o divulgación de su información personal</h3>
                <h4>Con objeto de que usted pueda limitar el uso y divulgación de su información personal, le ofrecemos los siguientes medios:</h4>
                <p>Su inscripción en el Registro Público para Evitar Publicidad, que está a cargo de la Procuraduría Federal del Consumidor, con la finalidad de que sus datos personales no sean utilizados para publicidad o promociones de empresas o bienes o servicios. Para más información favor de ponerse en contacto con la Procuraduría Federal del Consumidor.</p>
                <h3>VII.- Transferencia de datos personales.</h3>
                <h4>El Responsable comunica al Titular, mediante el presente aviso que podrá transferir datos personales a terceros nacionales o extranjeros, en los supuestos siguientes:</h4>
                <ul>
                    <li>A la institución financiera en la que el Responsable tenga sus cuentas bancarias, mediante la cual se realicen pagos por el Titular.</li>
                    <li>A terceros para la prestación de servicios de asesoría jurídica y/o contable y/o administrativa relativa a la elaboración de los diversos contratos, declaraciones, reportes y demás instrumentos legales que se requieran, así como con la interpelación judicial o extrajudicial para el cumplimiento de obligaciones.</li>
                    <li>A terceros que, a solicitud del propio Responsable, realicen una auditoria legal, contable o de cualquier otra naturaleza que requiera conocer los datos personales.</li>
                    
                </ul>
                <p>Sobre este particular, el Titular acepta que sus datos personales sean transmitidos conforme a este apartado.</p>
                <p>En todos los casos el Responsable dará a conocer a los terceros el contenido del presente aviso de privacidad.</p>
                <p>Salvo lo establecido en el presente documento y en el artículo 37 de la Ley, nos comprometemos a no transferir su información personal a terceros sin su consentimiento, así como a realizar esta transferencia en los términos que fija la mencionada Ley.</p>
                <h3>VIII.- Cambios al aviso de privacidad.</h3>
                <p>El presente aviso de Privacidad puede sufrir modificaciones, cambios o actualizaciones derivadas de los nuevos requerimientos legales; de nuestras propias necesidades por los productos o servicios que ofrecemos; de nuestras prácticas de privacidad; de cambios en nuestro modelo de negocio o por otros motivos.</p>
                <p>En el supuesto de que el Responsable requiera modificar el contenido del presente aviso de privacidad lo hará del conocimiento del Titular a efecto de obtener su consentimiento respecto al nuevo tratamiento de sus datos personales, para lo cual el aviso de privacidad estará a disposición del Titular en el domicilio señalado anteriormente.</p>
                <p>Lo anterior se realizará aplicando en lo conducente lo establecido en la propia Ley, para la manifestación de la voluntad del Titular, lo cual aplicará únicamente para los aspectos del tratamiento de datos personales diversos de los ya consentidos para este aviso de privacidad.</p>
                <h3>IX.- Consentimiento </h3>
                <p>Con fundamento en el Artículo 8 de la Ley Federal de Protección de Datos Personales en Posesión de los Particulares, consiento en entregar a 1 Atmos Hypoxico, S.A. de C.V., mis datos personales a efecto de que sean tratados conforme a lo consignado en este aviso de privacidad, el cual me fue facilitado con anterioridad a esta fecha, para su conocimiento oportuno y completo.</p>
                <p>Finalmente manifiesto que ninguno de los datos personales que este acto consciente sea tratados, los considero como datos que me pudieren afectar en aspectos íntimos o que puedan dar lugar a que se me discrimine o me representen un riesgo.</p>
                <p>Fecha de actualización: 19 de septiembre de 2019</p>

            </div>
        </article>
    </section>

<?php include "footer.php"; ?>
