<?php include "header.php"; ?>

<!-- YOUR HTML HERE -->
    <section class="internal-pages container">
        <!--div class="go-back">
            <a href="index.php"><i class="fa fa-chevron-left"></i></a>
        </div-->
        <div class="row">
            <div class="col-sm-12 col-md-6 col-lg-6 offset-md-3 offset-lg-3">

                <h1>Perfil</h1>
                <article class="profile-resume row">
                    <div class="profile-picture col-sm-12 col-md-4 col-lg-4">
                        <figure class="image-rounded">
                            <img src="../img/athlete.jpg" class="img-circle">
                        </figure>
                    </div>
                    <div class="profile-data  col-sm-12 col-md-8 col-lg-8">
                        <div class="profile-name">
                            Mario Vargas López
                        </div>
                        <div class="membership-status">
                            Membresía: Activa
                        </div>
                        <div class="membership-expiration">Vigencia 20/09/2020</div>
                    </div>
                </article>
            </div>
        </div>
    </section>
    <section class="next-bookings container">
        <div class="row">
            <div class="col-sm-12 col-md-6 col-lg-6 offset-md-3 offset-lg-3">
                <h3>Próximas reservaciones</h3>
                <div class="schedule-group">
                    <a href="#" class="cancel"><i class="fa fa-times-circle" alt="cancelar"></i></a>
                    <h5 class="schedule-label">Viernes 6 de agosto</h5>
                    <div class="next-schedule">6:00 - 7:00</div>
                    <div class="presion">5,000 MSNM</div>
                    
                </div>
                <div class="schedule-group">
                    <a href="#" class="cancel"><i class="fa fa-times-circle" alt="cancelar"></i></a>
                    <h5 class="schedule-label">Sábado 7 de agosto</h5>
                    <div class="next-schedule">8:00 - 10:00</div>
                    <div class="presion">3,200 MSNM</div>
                </div>
                <div class="schedule-group">
                    <a href="#" class="cancel"><i class="fa fa-times-circle" alt="cancelar"></i></a>
                    <h5 class="schedule-label">Lunes 9 de agosto</h5>
                    <div class="next-schedule">8:00 - 10:00</div>
                    <div class="presion">3,200 MSNM</div>
                </div>
                <a href="reservar.php" class="new-booking"><i class="fa fa-plus-circle"></i> Nueva reservación</a>
            </div>
        </div>
    </section>
    
<?php include "footer.php"; ?>
