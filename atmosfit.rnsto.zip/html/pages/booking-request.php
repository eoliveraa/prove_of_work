<?php include "header.php"; ?>

<!-- YOUR HTML HERE -->
    <section class="internal-pages container">
         <div class="row">
            <div class="col-sm-12 col-md-6 col-lg-6 offset-md-3 offset-lg-3">
                <div class="go-back">
                    <a href="index.php"><i class="fa fa-chevron-left"></i></a>
                </div>
                <h1>Confirma tu reservación</h1>
                <p>Los aparatos están disponibles en los horarios seleccionados, por favor confirma que la información es correcta.</p>
                <hr class="divider">
            </div>
        </div>
    </section>
    <section class="booking-resume container">
    <div class="row">
            <div class="col-sm-12 col-md-6 col-lg-6 offset-md-3 offset-lg-3">
                <h5>Bicicleta 1</h5>
                <figure class="booking-map">
                    <img src="../img/booking/bicicleta-1.png"/>
                </figure>
                <article class="next-bookings">
                    <h5>Horarios</h5>
                    <div class="schedule-group">
                        <h5 class="schedule-label">Viernes 6 de agosto</h5>
                        <div class="next-schedule">6:00 - 70:00</div>
                        <div class="presion">5,000 MSNM</div>
                    </div>
                    <div class="schedule-group">
                        <h5 class="schedule-label">Viernes 6 de agosto</h5>
                        <div class="next-schedule">8:00 - 10:00</div>
                        <div class="presion">3,200 MSNM</div>
                    </div>
                    <div class="schedule-group">
                        <h5 class="schedule-label">Viernes 6 de agosto</h5>
                        <div class="next-schedule">8:00 - 10:00</div>
                        <div class="presion">3,200 MSNM</div>
                    </div>
                </article>
        
                <a class="button primary-button col-sm-12 col-md-4 col-lg-4" href="booking-confirmation.php">Reservar</a>
                <a class="button secondary-button  col-sm-12 col-md-4 col-lg-4" href="reservar.php">Cambiar</a>
            </div>
        </div>
        
    </section>
<?php include "footer.php"; ?>
