<?php include "header.php"; ?>

<!-- YOUR HTML HERE -->
    <section class="internal-pages container">
        <div class="row">
            <div class="col-sm-12 col-md-6 col-lg-6 offset-md-3 offset-lg-3">
                <h1>Reservación exitosa</h1>
                <p>Por favor presenta el siguiente número de reserva en recepción Atmosfit.</p>
                <hr class="divider">
            </div>
        </div>
    </section>
    <section class="booking-resume container">
        <div class="row">
            <div class="col-sm-12 col-md-6 col-lg-6 offset-md-3 offset-lg-3">
                <h5>Bicicleta 1</h5>
                <figure class="booking-map">
                    <img src="../img/booking/bicicleta-1.png"/>
                </figure>
                <div class="booking-number">
                    ABCD4567
                </div>
                <article class="next-bookings">
                    <h5>Horarios</h5>
                    <div class="schedule-group">
                        <h5 class="schedule-label">Viernes 6 de agosto</h5>
                        <div class="next-schedule">6:00 - 7:00</div>
                        <div class="presion">5,000 MSNM</div>
                    </div>
                    <div class="schedule-group">
                        <h5 class="schedule-label">Viernes 6 de agosto</h5>
                        <div class="next-schedule">8:00 - 10:00</div>
                        <div class="presion">3,200 MSNM</div>
                    </div>
                    <div class="schedule-group">
                        <h5 class="schedule-label">Viernes 6 de agosto</h5>
                        <div class="next-schedule">8:00 - 10:00</div>
                        <div class="presion">3,200 MSNM</div>
                    </div>
                </article>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-6 col-lg-6 offset-md-3 offset-lg-3">
                <p>Tus reservaciones estarán disponibles en tu perfil y recibirás un correo electrónico de confirmación.</p>
                <a class="button primary-button  col-sm-12 col-md-6 col-lg-6" href="perfil.php">Ir a mi perfil</a>
                <!--form method="post" action="/download-ics.php">
                    <input type="hidden" name="date_start" value="2017-1-16 9:00AM">
                    <input type="hidden" name="date_end" value="2017-1-16 10:00AM">
                    <input type="hidden" name="location" value="Hidalgo 234, Monterrey Nuevo Leon">
                    <input type="hidden" name="description" value="Aparato seleccionado: Caminadora 1">
                    <input type="hidden" name="summary" value="Reservación Atmosfit">
                    <input type="hidden" name="url" value="https://atmosfit.com/perfil.php">
                    <input type="submit"  class="button secondary-button  col-sm-12 col-md-6 col-lg-6" value="Añadir a calendario">
                </form-->
            </div>
        </div>
        
    </section>
<?php include "footer.php"; ?>
