<?php include "header.php"; ?>

<!-- YOUR HTML HERE -->
    <section class="hero-banner">
        <figure class="background-image">
            <img src="../img/686.jpg"/>
        </figure>
        <article class="banner-content overlay--1">
            <div class="heading container">
                <h1>Entrenamiento en altura simulada</h1>
            </div>
            <div class="subheader container">
                <h2>Obtén todo el poder que hay dentro de ti</h2>
                <a href="#" class="button ghost--button">Descubre como</a>
            </div>            
        </article>
    </section>
    <section class="value-cta col-xs-12">
        <article class="content container">
            <p>Aumenta la resistencia de tu cuerpo acostumbrándolo a un entorno con poco oxígeno produciendo más glóbulos rojos</p>
            <h3>Observa resultados desde la primer semana</h3>
            <a class="button primary-button" href="#">Reservar ahora</a>
        </article>
    </section>
    <section class="booking-module container">
        <!--h4>Tutorial de tabs <a href="https://mdbootstrap.com/docs/jquery/components/tabs/" target="_blank">Clic aquí</a></h4-->
        <h4>Reserva tu entrenamiento</h4>
        <ul class="nav nav-tabs" id="myTab" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" id="por-dia" data-toggle="tab" href="#home" role="tab" aria-controls="home"
              aria-selected="true">Por día</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" id="por-rutina" data-toggle="tab" href="#profile" role="tab" aria-controls="profile"
              aria-selected="false">Por rutina</a>
          </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="por-dia">
                <p>Selecciona la fecha y horario para tu entrenamiento</p>
                <form class="training-plan type--a">
                    <div class="form-row row">
                        <label>Fecha</label>
                        <input type="date" placeholder="Elige la fecha">
                    </div>
                    <div class="form-row row">
                        <label>Hora</label>
                        <input type="time" placeholder="Elige un horario">
                    </div>
                    <div class="form-row row">
                        <label>Elige el equipo</label>
                        <div class="equipment-slider col-sm-12 col-md-4">
                            <div class="item equipment-item col-sm-12">
                                <label for="aa">Bicicleta
                                    <figure class="equipment-picture">
                                        <img src="../img/iC5-LifeFitness-bike-sideview-L.png"/>
                                    </figure>
                                    <input type="radio" id="aa" name="eq-selection" value="bici1">
                                    <a class="see-more" href="#">Más información</a>
                                </label>
                            </div>
                            <div class="item equipment-item col-sm-12">
                                <label for="bb">Escaladora
                                    <figure class="equipment-picture">
                                        <img src="../img/ElevationSeries-PowerMill-Climber-DiscoverSE3-HD-ArcticSilver-StandardView.png"/>
                                    </figure>
                                    <input type="radio" id="bb" name="eq-selection" value="Escaladora">
                                    <a class="see-more" href="#">Más información</a>
                                </label>
                            </div>
                            <div class="item equipment-item col-sm-12">
                                <label for="cc">Caminadora
                                    <figure class="equipment-picture">
                                        <img src="../img/ElevationSeries-Treadmill-DiscoverSE3-HD-ArcticSilver-StandardView.png"/>
                                    </figure>
                                    <input type="radio" id="cc" name="eq-selection" value="Caminadora">
                                    <a class="see-more" href="#">Más información</a>
                                </label>
                            </div>
                        </div> 
                    </div>
                    <a class="button primary-button" href="#">Reservar</a>
                </form>
            </div>
            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="por-rutina">
                <p>Selecciona la fecha y horario para tu entrenamiento</p>
                <form class="training-plan type--a">
                    
                    <div class="form-row row">
                        <label>Elige el equipo</label>
                        <div class="equipment-slider col-sm-12 col-md-4">
                            <div class="item equipment-item col-sm-12">
                                <label for="aa">Bicicleta
                                    <figure class="equipment-picture">
                                        <img src="../img/iC5-LifeFitness-bike-sideview-L.png"/>
                                    </figure>
                                    <input type="radio" id="aa" name="eq-selection" value="bici1">
                                    <a class="see-more" href="#">Más información</a>
                                </label>
                            </div>
                            <div class="item equipment-item col-sm-12">
                                <label for="bb">Escaladora
                                    <figure class="equipment-picture">
                                        <img src="../img/ElevationSeries-PowerMill-Climber-DiscoverSE3-HD-ArcticSilver-StandardView.png"/>
                                    </figure>
                                    <input type="radio" id="bb" name="eq-selection" value="Escaladora">
                                    <a class="see-more" href="#">Más información</a>
                                </label>
                            </div>
                            <div class="item equipment-item col-sm-12">
                                <label for="cc">Caminadora
                                    <figure class="equipment-picture">
                                        <img src="../img/ElevationSeries-Treadmill-DiscoverSE3-HD-ArcticSilver-StandardView.png"/>
                                    </figure>
                                    <input type="radio" id="cc" name="eq-selection" value="Caminadora">
                                    <a class="see-more" href="#">Más información</a>
                                </label>
                            </div>
                        </div> 
                    </div>
                    
                    <div class="form-row row">
                        <label>Hora</label>
                        <input type="time" placeholder="Elige un horario">
                    </div>
                    <div class="form-row row">
                        <label>Fecha</label>
                        <input type="date" placeholder="Elige la fecha">
                    </div>
                    <a class="button primary-button" href="#">Reservar</a>
                </form>
            </div>
        </div>
    </section>
    <section class="plan-selection container">
        <h3 class="headshot-copy">
            Entrenamiento a 3,200 M.S.N.M. Diseñado para deportistas de alto rendimiento.
        </h3>
        <h4>Paquetes de sesiones</h4>
        <p>Compra una sesión o un paquete
            para facilitar tu reservación.</p>
        <h5>Sesiones</h5>
        <div class="plan-selection-slider">
            <div class="item">
                <h4>1 sesión</h4>
                <div class="price-label">$270</div>
                <a class="vigencia" href="#">Vigencia 10 días</a>
                <a class="button primary-button" href="#">Reservar</a>
            </div>
            <div class="item">
                <h4>5 sesiones</h4>
                <div class="price-label">$1,250</div>
                <a class="vigencia" href="#">Vigencia 25 días</a>
                <a class="button primary-button" href="#">Reservar</a>
            </div>
            <div class="item">
                <h4>10 sesiones</h4>
                <div class="price-label">$2,400</div>
                <a class="vigencia" href="#">Vigencia 45 días</a>
                <a class="button primary-button" href="#">Reservar</a>
            </div>
        </div>
    </section>

<?php include "footer.php"; ?>
