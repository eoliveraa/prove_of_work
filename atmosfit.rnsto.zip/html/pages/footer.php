    <footer>
        <div class="container">
            <div class="row">
                <figure class="footer-logo">
                    <img src="../img/brand/atmosfit--white.svg"/>
                </figure>
            </div>
            <div class="row">
                <div class="direccion col-sm-12 col-md-4 col-lg-4">
                    <h5>Conócenos</h5>
                    <h4>Atmosfit Monterrey</h4>
                    <p>Plaza RGS 101 local 305 Ave. Roberto Garza Sada 101, Col Carrizalejo, San Pedro Garza Garcia, NL<br>
                     Tel: (52) (81) 8130.6565</p>
                </div>
                <div class="footer-icons  col-sm-12 col-md-8 col-lg-8">
                    <ul class="social-icons">
                        <li><a href="https://www.facebook.com/atmosfit.mx/"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://www.instagram.com/atmosfit_mx"><i class="fa fa-instagram"></i></a></li>
                    </ul>
                    <h5>Pagos seguros</h5>
                    <ul class="pay-icons">
                        <li>
                            <figure>
                                <img src="../img/banregio.svg">
                            </figure>
                        </li>
                        <li><i class="fa fa-cc-amex"></i></li>
                        <li><i class="fa fa-cc-visa"></i></li>
                        <li><i class="fa fa-cc-mastercard"></i></li>
                    </ul>
                </div>
            </div>
            <div class="row">
                <div class="footer-links col-12">
                    <h5>&copy; Copyright Atomisfit 2019</h5>
                    <a href="privacidad.php">Aviso de privacidad | </a>
                    <a href="terminos-y-condiciones.php">Términos y condiciones </a>
                </div>
            </div>
        </div>
    </footer>

    <!-- SCRIPTS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>-->
    <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
    <script type="text/javascript" src="../js/plugins/panzoom.js"></script>
    <script type="text/javascript" src="../js/plugins/jquery.datetimepicker.full.min.js"></script>
    <script type="text/javascript" src="../js/plugins/jquery.mousewheel.js"></script>
    <script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>

    
    <script src="https://apis.google.com/js/api:client.js"></script>
    <script src="../plugins/pickdate/picker.js"></script>
    <script src="../js/scripts.min.js"></script>
    <script>startApp();</script>
    <script>
        // Js radio check
        $(".js-radio-check").each(function(){
            $(this).on('click keyup change drop paste touchstart', function() {
                if(this.checked) {
                    //Do stuff
                    $(".map__item").removeClass("active");
                    $(this).parent(".map__item").addClass("active");
                    console.log("checked -->");
                }
            });
        });
        

        // Stop propagation
        $('.js-radio-check').on('mousedown touchstart', function( e ) {
            e.stopImmediatePropagation();
        });


        // Mapzoom 1
        (function() {
            var mapOne =  $('#js-map-zoom');
            var mapTwo =  $('#js-map-zoom--2');
            //MapOne
          mapOne.find('.panzoom').panzoom({
            increment: 0.2,
            minScale: 1,
            maxScale: 2,
            duration: 300,
            contain: "invert",
            $zoomIn: mapOne.find(".zoom-in"),
            $zoomOut: mapOne.find(".zoom-out"),
          });
            //MapTwo
          mapTwo.find('.panzoom').panzoom({
            increment: 0.2,
            minScale: 1,
            maxScale: 2,
            duration: 300,
            contain: "invert",
            $zoomIn: mapTwo.find(".zoom-in"),
            $zoomOut: mapTwo.find(".zoom-out"),
          });
        })();


        // Zoom
        (function() {
            var $section = $('#js-map-zoom');
            var $panzoom = $section.find('.panzoom').panzoom();
            $panzoom.parent().on('mousewheel.focal', function( e ) {
            e.preventDefault();
            var delta = e.delta || e.originalEvent.wheelDelta;
            var zoomOut = delta ? delta < 0 : e.originalEvent.deltaY > 0;
            $panzoom.panzoom('zoom', zoomOut, {
                increment: 0.1,
                animate: false,
                focal: e
            });
            });
        })();

        // Zoom
        (function() {
              var $section = $('#js-map-zoom--2');
              var $panzoom = $section.find('.panzoom').panzoom();
              $panzoom.parent().on('mousewheel.focal', function( e ) {
                e.preventDefault();
                var delta = e.delta || e.originalEvent.wheelDelta;
                var zoomOut = delta ? delta < 0 : e.originalEvent.deltaY > 0;
                $panzoom.panzoom('zoom', zoomOut, {
                  increment: 0.1,
                  animate: false,
                  focal: e
                });
              });
            })();
      

        // Datepicker
        $('#datetimepicker--month').datetimepicker({
            timepicker:false,
            format:'d.m.Y'
        });
        $('#datetimepicker--hour').datetimepicker({
            datepicker:false,
            format:'H:i'
        });
        $('#datetimepicker--month-2').datetimepicker({
            timepicker:false,
            format:'d.m.Y'
        });
       
    </script>
        
</body>
</html>
