<?php include "header.php"; ?>
<!-- YOUR HTML HERE -->  
    <section class="internal-pages container">
    
        <div class="go-back">
            <a href="index.php"><i class="fa fa-chevron-left"></i></a>
        </div>
        <h1>Selecciona tu plan</h1>
        
    </section>
<?php include "plan-selection-module.php"; ?>
<?php include "footer.php"; ?>
