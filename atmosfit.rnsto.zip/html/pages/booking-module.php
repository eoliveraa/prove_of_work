<section class="booking-module container">

    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="tab--por-dia" data-toggle="tab" href="#por-dia" role="tab" aria-controls="por-dia" aria-selected="true">Por día</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="tab--por-rutina" data-toggle="tab" href="#por-rutina" role="tab" aria-controls="por-rutina" aria-selected="false">Por rutina</a>
        </li>
    </ul>
    <article class="tab-content container" id="myTabContent">
        <div class="tab-pane fade show active" id="por-dia" role="tabpanel" aria-labelledby="por-dia">
            <p>Selecciona la fecha y horario para tu entrenamiento</p>
            <h5>Tienes --N-- sesiones disponibles</h5>
            <form class="training-plan basic-form type--a">
                <div class="form-row row">
                    <div class="input-group col-sm-12 col-md-4 col-lg-4">
                        <label>Fecha</label>
                        <input type="text" placeholder="Elige la fecha" id="datetimepicker--month" class="desktop-only">
                        <input type="date" placeholder="Elige la fecha" class="mobile-only">
                        
                    </div>
                    <div class="input-group col-sm-12 col-md-4 col-lg-4">
                        <label>Hora</label>
                        <input type="text" placeholder="Elige un horario" id="datetimepicker--hour" class="desktop-only">
                        <input type="time" placeholder="Elige un horario" class="mobile-only">
                    </div>
                    <div class="input-group col-sm-12 col-md-4 col-lg-4">
                        <label>Elige la presión para entrenar</label>
                        <select>
                            <option>3,200 MSNM</option>
                            <option>3,800 MSNM</option>
                            <option>4,200 MSNM</option>
                        </select>
                    </div>
                </div>
                <div class="row form-row">
                    <div class="input-group col-sm-12 col-md-8 col-lg-8">
                        <div class="eq-map-selection ">
                            <h4>Elige el equipo</h4>
                             <!-- Map section -->
                            <section class="map-wrapp" id="js-map-zoom">
                                <section class="map-zoom panzoom">
                                    <div class="map__body">
                                        <!-- top -->
                                        <div class="map__top">
                                            <div class="row">
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item">
                                                        <input type="radio" name="eq-selection-radio" value="Escalera-D1" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/escalera.png" alt="Escalera">
                                                        </figure>
                                                        <p>Escalera</p>
                                                    </article>
                                                </div><!-- / -->
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item">
                                                        <input type="radio" name="eq-selection-radio" value="Bicicleta-D1" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/bicicleta.png" alt="Bicicleta">
                                                        </figure>
                                                        <p>Bicicleta</p>
                                                    </article>
                                                </div><!-- / -->
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item  map--disabled">
                                                        <input type="radio" name="eq-selection-radio" value="Bicicleta-D2" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/bicicleta.png" alt="Bicicleta">
                                                        </figure>
                                                        <p>Bicicleta</p>
                                                    </article>
                                                </div><!-- / -->
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item map--size2">
                                                        <input type="radio" id="radio--caminadora1" name="eq-selection-radio" value="Caminadora-D1" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/caminadora.png" alt="Caminadora">
                                                        </figure>
                                                        <p>Caminadora</p>
                                                    </article>
                                                </div><!-- / -->
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item map--size2">
                                                        <input type="radio" id="radio--caminadora1" name="eq-selection-radio" value="Caminadora-D2" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/caminadora.png" alt="Caminadora">
                                                        </figure>
                                                        <p>Caminadora</p>
                                                    </article>
                                                </div><!-- / -->
                                            </div>
                                        </div>
                                        <!-- bottom -->
                                        <div class="map__bottom">
                                            <div class="row">
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item">
                                                        <input type="radio" name="eq-selection-rodillo" value="Rodillo-D1" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/rodillo.png" alt="Rodillo">
                                                        </figure>
                                                        <p>Rodillo</p>
                                                    </article>
                                                </div><!-- / -->
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item">
                                                        <input type="radio" name="eq-selection-radio" value="Bicicleta-D3" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/bicicleta.png" alt="Bicicleta">
                                                        </figure>
                                                        <p>Bicicleta</p>
                                                    </article>
                                                </div><!-- / -->
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item">
                                                        <input type="radio" name="eq-selection-radio" value="Bicicleta-D4" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/bicicleta.png" alt="Bicicleta">
                                                        </figure>
                                                        <p>Bicicleta</p>
                                                    </article>
                                                </div><!-- / -->
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item">
                                                        <input type="radio" name="eq-selection-radio" value="Bicicleta-D5" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/bicicleta.png" alt="Bicicleta">
                                                        </figure>
                                                        <p>Bicicleta</p>
                                                    </article>
                                                </div><!-- / -->
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item">
                                                        <input type="radio" name="eq-selection-radio" value="Bicicleta-D6" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/bicicleta.png" alt="Bicicleta">
                                                        </figure>
                                                        <p>Bicicleta</p>
                                                    </article>
                                                </div><!-- / -->
                                                <!-- tiem -->
                                                <div class="map__span span--size2 col-2">
                                                    <article class="map__item map--size2">
                                                        <input type="radio" id="radio--caminadora1" name="eq-selection-radio" value="Caminadora-D3" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/caminadora.png" alt="Caminadora">
                                                        </figure>
                                                        <p>Caminadora</p>
                                                    </article>
                                                </div><!-- / -->
                                            </div>
                                        </div>
                                        <!-- enter -->
                                        <img src="../img/map/element/enter.svg" class="enter-img">
                                        <img src="../img/map/element/line-arrow.svg" class="line-enter-img">
                                        <!-- title -->
                                        <div class="map__title-bottom">
                                        <div class="title-bottom__span">
                                            <p>Ventana</p>
                                        </div>
                                    </div>
                                </div>
                                </section><!-- / -->
                                <div class="buttons">
                                    <button type="button" class="zoom-in">
                                        <img src="../img/icons/zoom-in.svg" alt="Zoom in">
                                    </button>
                                    <button type="button" class="zoom-out">
                                        <img src="../img/icons/zoom-out.svg" alt="Zoom out">
                                    </button>
                                </div>
                            </section>
                        </div>
                    </div>
                    
                    <div class="eq-details col-sm-12 col-md-4 col-lg-4">
                        <div class="detail-item" id="item-Bicicleta-D1">
                            <h4>Tu Selección</h4>
                            <h5>Bicicleta 1</h5>
                            <figure class="equipment-picture">
                                <img src="../img/iC5-LifeFitness-bike-sideview-L.png" />
                            </figure>
                            <p>Bicicleta con powermeter para medir rendimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Bicicleta-D2">
                            <h4>Tu Selección</h4>
                            <h5>Bicicleta 2</h5>
                            <figure class="equipment-picture">
                                <img src="../img/iC5-LifeFitness-bike-sideview-L.png" />
                            </figure>
                            <p>Bicicleta con powermeter para medir rendimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Bicicleta-D3">
                            <h4>Tu Selección</h4>
                            <h5>Bicicleta 3</h5>
                            <figure class="equipment-picture">
                                <img src="../img/iC5-LifeFitness-bike-sideview-L.png" />
                            </figure>
                            <p>Bicicleta con powermeter para medir rendimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Bicicleta-D4">
                            <h4>Tu Selección</h4>
                            <h5>Bicicleta 4</h5>
                            <figure class="equipment-picture">
                                <img src="../img/iC5-LifeFitness-bike-sideview-L.png" />
                            </figure>
                            <p>Bicicleta con powermeter para medir rendimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Bicicleta-D5">
                            <h4>Tu Selección</h4>
                            <h5>Bicicleta 5</h5>
                            <figure class="equipment-picture">
                                <img src="../img/iC5-LifeFitness-bike-sideview-L.png" />
                            </figure>
                            <p>Bicicleta con powermeter para medir rendimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Bicicleta-D6">
                            <h4>Tu Selección</h4>
                            <h5>Bicicleta 6</h5>
                            <figure class="equipment-picture">
                                <img src="../img/iC5-LifeFitness-bike-sideview-L.png" />
                            </figure>
                            <p>Bicicleta con powermeter para medir rendimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Escalera-D1">
                            <h4>Tu Selección</h4>
                            <h5>Escalera</h5>
                            <figure class="equipment-picture">
                                <img src="../img/ElevationSeries-PowerMill-Climber-DiscoverSE3-HD-ArcticSilver-StandardView.png" />
                            </figure>
                            <p>Escalera inteligente con aplicaciones de youtube y netflix de entretenimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Caminadora-D1">
                            <h4>Tu Selección</h4>
                            <h5>Caminadora 1</h5>
                            <figure class="equipment-picture">
                                <img src="../img/ElevationSeries-Treadmill-DiscoverSE3-HD-ArcticSilver-StandardView.png" />
                            </figure>
                            <p>Caminadora inteligente con aplicaciones de youtube y netflix de entretenimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Caminadora-D2">
                            <h4>Tu Selección</h4>
                            <h5>Caminadora 2</h5>
                            <figure class="equipment-picture">
                                <img src="../img/ElevationSeries-Treadmill-DiscoverSE3-HD-ArcticSilver-StandardView.png" />
                            </figure>
                            <p>Caminadora inteligente con aplicaciones de youtube y netflix de entretenimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Caminadora-D3">
                            <h4>Tu Selección</h4>
                            <h5>Caminadora 3</h5>
                            <figure class="equipment-picture">
                                <img src="../img/ElevationSeries-Treadmill-DiscoverSE3-HD-ArcticSilver-StandardView.png" />
                            </figure>
                            <p>Caminadora inteligente con aplicaciones de youtube y netflix de entretenimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Rodillo-D1">
                            <h4>Tu Selección</h4>
                            <h5>Rodillo</h5>
                            <figure class="equipment-picture">
                                <img src="../img/ElevationSeries-Treadmill-DiscoverSE3-HD-ArcticSilver-StandardView.png" />
                            </figure>
                            <p>Rodillo marca wahoo kickr con laptop para medición de métricas de ciclismo. Indispensable traer su propia bicicleta.</p>
                        </div>
                    </div>
                </div>
                <div class="form-row row">
                    <a class="button primary-button col-sm-12 col-md-4 col-lg-4 offset-md-8 offset-lg-8" href="booking-request.php">Reservar</a>
                </div>
            </form>
        </div>
        <div class="tab-pane fade" id="por-rutina" role="tabpanel" aria-labelledby="por-rutina">
            <p>Selecciona tu equipo</p>
            <form class="training-plan type--b">
                <div class="form-row row">
                    <div class="input-group col-sm-12 col-md-8 col-lg-8">
                        <div class="eq-map-selection ">
                            <h4>Elige el equipo</h4>
                             <!-- Map section -->
                            <section class="map-wrapp" id="js-map-zoom--2">
                                <section class="map-zoom panzoom">
                                    <div class="map__body">
                                        <!-- top -->
                                        <div class="map__top">
                                            <div class="row">
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item">
                                                        <input type="radio" name="eq-selection-radio" value="Escalera-R1" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/escalera.png" alt="Escalera">
                                                        </figure>
                                                        <p>Escalera</p>
                                                    </article>
                                                </div><!-- / -->
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item">
                                                        <input type="radio" name="eq-selection-radio" value="Bicicleta-R1" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/bicicleta.png" alt="Bicicleta">
                                                        </figure>
                                                        <p>Bicicleta</p>
                                                    </article>
                                                </div><!-- / -->
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item  map--disabled">
                                                        <input type="radio" name="eq-selection-radio" value="Bicicleta-R2" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/bicicleta.png" alt="Bicicleta">
                                                        </figure>
                                                        <p>Bicicleta</p>
                                                    </article>
                                                </div><!-- / -->
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item map--size2">
                                                        <input type="radio" id="radio--caminadora1" name="eq-selection-radio" value="Caminadora-R1" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/caminadora.png" alt="Caminadora">
                                                        </figure>
                                                        <p>Caminadora</p>
                                                    </article>
                                                </div><!-- / -->
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item map--size2">
                                                        <input type="radio" id="radio--caminadora1" name="eq-selection-radio" value="Caminadora-R2" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/caminadora.png" alt="Caminadora">
                                                        </figure>
                                                        <p>Caminadora</p>
                                                    </article>
                                                </div><!-- / -->
                                            </div>
                                        </div>
                                        <!-- bottom -->
                                        <div class="map__bottom">
                                            <div class="row">
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item">
                                                        <input type="radio" name="eq-selection-rodillo" value="Rodillo-R1" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/rodillo.png" alt="Rodillo">
                                                        </figure>
                                                        <p>Rodillo</p>
                                                    </article>
                                                </div><!-- / -->
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item">
                                                        <input type="radio" name="eq-selection-radio" value="Bicicleta-R3" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/bicicleta.png" alt="Bicicleta">
                                                        </figure>
                                                        <p>Bicicleta</p>
                                                    </article>
                                                </div><!-- / -->
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item">
                                                        <input type="radio" name="eq-selection-radio" value="Bicicleta-R4" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/bicicleta.png" alt="Bicicleta">
                                                        </figure>
                                                        <p>Bicicleta</p>
                                                    </article>
                                                </div><!-- / -->
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item">
                                                        <input type="radio" name="eq-selection-radio" value="Bicicleta-R5" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/bicicleta.png" alt="Bicicleta">
                                                        </figure>
                                                        <p>Bicicleta</p>
                                                    </article>
                                                </div><!-- / -->
                                                <!-- tiem -->
                                                <div class="map__span col-2">
                                                    <article class="map__item">
                                                        <input type="radio" name="eq-selection-radio" value="Bicicleta-R6" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/bicicleta.png" alt="Bicicleta">
                                                        </figure>
                                                        <p>Bicicleta</p>
                                                    </article>
                                                </div><!-- / -->
                                                <!-- tiem -->
                                                <div class="map__span span--size2 col-2">
                                                    <article class="map__item map--size2">
                                                        <input type="radio" id="radio--caminadora1" name="eq-selection-radio" value="Caminadora-R3" class="js-radio-check">
                                                        <figure class="item__img">
                                                            <img src="../img/map/aparatos/caminadora.png" alt="Caminadora">
                                                        </figure>
                                                        <p>Caminadora</p>
                                                    </article>
                                                </div><!-- / -->
                                            </div>
                                        </div>
                                        <!-- enter -->
                                        <img src="../img/map/element/enter.svg" class="enter-img">
                                        <img src="../img/map/element/line-arrow.svg" class="line-enter-img">
                                        <!-- title -->
                                        <div class="map__title-bottom">
                                        <div class="title-bottom__span">
                                            <p>Ventana</p>
                                        </div>
                                    </div>
                                </div>
                                </section><!-- / -->
                                <div class="buttons">
                                    <button type="button" class="zoom-in">
                                        <img src="../img/icons/zoom-in.svg" alt="Zoom in">
                                    </button>
                                    <button type="button" class="zoom-out">
                                        <img src="../img/icons/zoom-out.svg" alt="Zoom out">
                                    </button>
                                </div>
                            </section>
                        </div>
                    </div>
                    <div class="eq-details col-sm-12 col-md-4 col-lg-4">
                        <div class="detail-item" id="item-Bicicleta-R1">
                            <h4>Tu Selección</h4>
                            <h5>Bicicleta 1</h5>
                            <figure class="equipment-picture">
                                <img src="../img/iC5-LifeFitness-bike-sideview-L.png" />
                            </figure>
                            <p>Bicicleta con powermeter para medir rendimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Bicicleta-R2">
                            <h4>Tu Selección</h4>
                            <h5>Bicicleta 2</h5>
                            <figure class="equipment-picture">
                                <img src="../img/iC5-LifeFitness-bike-sideview-L.png" />
                            </figure>
                            <p>Bicicleta con powermeter para medir rendimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Bicicleta-R3">
                            <h4>Tu Selección</h4>
                            <h5>Bicicleta 3</h5>
                            <figure class="equipment-picture">
                                <img src="../img/iC5-LifeFitness-bike-sideview-L.png" />
                            </figure>
                            <p>Bicicleta con powermeter para medir rendimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Bicicleta-R4">
                            <h4>Tu Selección</h4>
                            <h5>Bicicleta 4</h5>
                            <figure class="equipment-picture">
                                <img src="../img/iC5-LifeFitness-bike-sideview-L.png" />
                            </figure>
                            <p>Bicicleta con powermeter para medir rendimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Bicicleta-R5">
                            <h4>Tu Selección</h4>
                            <h5>Bicicleta 5</h5>
                            <figure class="equipment-picture">
                                <img src="../img/iC5-LifeFitness-bike-sideview-L.png" />
                            </figure>
                            <p>Bicicleta con powermeter para medir rendimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Bicicleta-R6">
                            <h4>Tu Selección</h4>
                            <h5>Bicicleta 6</h5>
                            <figure class="equipment-picture">
                                <img src="../img/iC5-LifeFitness-bike-sideview-L.png" />
                            </figure>
                            <p>Bicicleta con powermeter para medir rendimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Escalera-R1">
                            <h4>Tu Selección</h4>
                            <h5>Escalera</h5>
                            <figure class="equipment-picture">
                                <img src="../img/ElevationSeries-PowerMill-Climber-DiscoverSE3-HD-ArcticSilver-StandardView.png" />
                            </figure>
                            <p>Escalera inteligente con aplicaciones de youtube y netflix de entretenimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Caminadora-R1">
                            <h4>Tu Selección</h4>
                            <h5>Caminadora 1</h5>
                            <figure class="equipment-picture">
                                <img src="../img/ElevationSeries-Treadmill-DiscoverSE3-HD-ArcticSilver-StandardView.png" />
                            </figure>
                            <p>Caminadora inteligente con aplicaciones de youtube y netflix de entretenimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Caminadora-R2">
                            <h4>Tu Selección</h4>
                            <h5>Caminadora 2</h5>
                            <figure class="equipment-picture">
                                <img src="../img/ElevationSeries-Treadmill-DiscoverSE3-HD-ArcticSilver-StandardView.png" />
                            </figure>
                            <p>Caminadora inteligente con aplicaciones de youtube y netflix de entretenimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Caminadora-R3">
                            <h4>Tu Selección</h4>
                            <h5>Caminadora 3</h5>
                            <figure class="equipment-picture">
                                <img src="../img/ElevationSeries-Treadmill-DiscoverSE3-HD-ArcticSilver-StandardView.png" />
                            </figure>
                            <p>Caminadora inteligente con aplicaciones de youtube y netflix de entretenimiento.</p>
                        </div>
                        <div class="detail-item" id="item-Rodillo-R1">
                            <h4>Tu Selección</h4>
                            <h5>Rodillo</h5>
                            <figure class="equipment-picture">
                                <img src="../img/ElevationSeries-Treadmill-DiscoverSE3-HD-ArcticSilver-StandardView.png" />
                            </figure>
                            <p>Rodillo marca wahoo kickr con laptop para medición de métricas de ciclismo. Indispensable traer su propia bicicleta.</p>
                        </div>
                    </div>
                </div>
                <p>Selecciona la fecha y horario para tu entrenamiento</p>

                <div class="schedule-selection row form-row">
                    <div class="col-sm-12 col-md-6 col-lg-6 offset-md-3 offset-lg-3" id="accordion">
                        <input type="month" value="2019-09">
                        <!--input type="text" name="start"  id="datetimepicker--month-2" value="2019-09"-->
                        <ul class="accordion-day">
                            <li class="day-container">
                                <div class="day-header js-acc-trigger">
                                    <h5>Domingo 22</h5>
                                    <i class="fa fa-angle-up"></i>
                                </div>
                                <ul class="accordion-schedule js-acc-content active">
                                    <li class="availability available">
                                        <label for="D--6-7">
                                            <h5 class="schedule-label">6:00 - 7:00</h5>
                                            <div class="presion">4,200 MSNM</div>
                                        </label>
                                        <input type="checkbox" name="D--6-7" value="D--6-7" id="D--6-7">
                                    </li>
                                    <li class="availability available">
                                        <label for="D--7-8">
                                            <h5 class="schedule-label">7:00 - 8:00</h5>
                                            <div class="presion">4,200 MSNM</div>
                                        </label>
                                        <input type="checkbox" name="D--7-8" value="D--7-8" id="D--7-8">
                                    </li>
                                    <li class="availability available">
                                        <label for="D--8-9">
                                            <h5 class="schedule-label">8:00 - 9:00</h5>
                                            <div class="presion">3,200 MSNM</div>
                                        </label>
                                        <input type="checkbox" name="D--8-9" value="D--8-9" id="D--8-9">
                                    </li>
                                    <li class="availability available">
                                        <label for="D--9-10">
                                            <h5 class="schedule-label">9:00 - 10:00</h5>
                                            <div class="presion">3,200 MSNM</div>
                                        </label>
                                        <input type="checkbox" name="D--9-10" value="D--9-10" id="D--9-10">
                                    </li>
                                </ul>
                            </li>
                            <li class="day-container">
                                <div class="day-header js-acc-trigger">
                                    <h5>Lunes 23</h5>
                                    <i class="fa fa-angle-down"></i>
                                </div>
                                <ul class="accordion-schedule js-acc-content">
                                    <li class="availability available">
                                        <label for="L--6-7">
                                            <h5 class="schedule-label">6:00 - 7:00</h5>
                                            <div class="presion">3,200 MSNM</div>
                                        </label>
                                        <input type="checkbox" name="L--6-7" value="L--6-7" id="L--6-7">
                                    </li>
                                    <li class="availability available">
                                        <label for="L--7-8">
                                            <h5 class="schedule-label">7:00 - 8:00</h5>
                                            <div class="presion">3,200 MSNM</div>
                                        </label>
                                        <input type="checkbox" name="L--7-8" value="L--7-8" id="L--7-8">
                                    </li>
                                    <li class="availability available">
                                        <label for="L--8-9">
                                            <h5 class="schedule-label">8:00 - 9:00</h5>
                                            <div class="presion">3,200 MSNM</div>
                                        </label>
                                        <input type="checkbox" name="L--8-9" value="L--8-9" id="L--8-9">
                                    </li>
                                    <li class="availability available">
                                        <label for="L--9-10">
                                            <h5 class="schedule-label">9:00 - 10:00</h5>
                                            <div class="presion">3,200 MSNM</div>
                                        </label>
                                        <input type="checkbox" name="L--9-10" value="L--9-10" id="L--9-10">
                                    </li>
                                </ul>
                            </li>
                            <li class="day-container">
                                <div class="day-header js-acc-trigger">
                                    <h5>Martes 24</h5>
                                    <i class="fa fa-angle-down"></i>
                                </div>
                                <ul class="accordion-schedule js-acc-content">
                                    <li class="availability available">
                                        <label for="MA--6-7">
                                            <h5 class="schedule-label">6:00 - 7:00</h5>
                                            <div class="presion">5,000 MSNM</div>
                                        </label>
                                        <input type="checkbox" name="MA--6-7" value="MA--6-7" id="MA--6-7">
                                    </li>
                                    <li class="availability available">
                                        <label for="MA--7-8">
                                            <h5 class="schedule-label">7:00 - 8:00</h5>
                                            <div class="presion">3,200 MSNM</div>
                                        </label>
                                        <input type="checkbox" name="MA--7-8" value="MA--7-8" id="MA--7-8">
                                    </li>
                                    <li class="availability available">
                                        <label for="MA--8-9">
                                            <h5 class="schedule-label">8:00 - 9:00</h5>
                                            <div class="presion">3,200 MSNM</div>
                                        </label>
                                        <input type="checkbox" name="MA--8-9" value="MA--8-9" id="MA--8-9">
                                    </li>
                                    <li class="availability available">
                                        <label for="MA--9-10">
                                            <h5 class="schedule-label">9:00 - 10:00</h5>
                                            <div class="presion">3,200 MSNM</div>
                                        </label>
                                        <input type="checkbox" name="MA--9-10" value="MA--9-10" id="MA--9-10">
                                    </li>
                                </ul>
                            </li>
                            <li class="day-container">
                                <div class="day-header js-acc-trigger">
                                    <h5>Miércoles 25</h5>
                                    <i class="fa fa-angle-down"></i>
                                </div>
                                <ul class="accordion-schedule js-acc-content">
                                    <li class="availability available">
                                        <label for="MI--6-7">
                                            <h5 class="schedule-label">6:00 - 7:00</h5>
                                            <div class="presion">5,000 MSNM</div>
                                        </label>
                                        <input type="checkbox" name="MI--6-7" value="MI--6-7" id="MI--6-7">
                                    </li>
                                    <li class="availability available">
                                        <label for="MI--7-8">
                                            <h5 class="schedule-label">7:00 - 8:00</h5>
                                            <div class="presion">3,200 MSNM</div>
                                        </label>
                                        <input type="checkbox" name="MI--7-8" value="MI--7-8" id="MI--7-8">
                                    </li>
                                    <li class="availability available">
                                        <label for="MI--8-9">
                                            <h5 class="schedule-label">8:00 - 9:00</h5>
                                            <div class="presion">3,200 MSNM</div>
                                        </label>
                                        <input type="checkbox" name="MI--8-9" value="MI--8-9" id="MI--8-9">
                                    </li>
                                    <li class="availability available">
                                        <label for="MI--9-10">
                                            <h5 class="schedule-label">9:00 - 10:00</h5>
                                            <div class="presion">3,200 MSNM</div>
                                        </label>
                                        <input type="checkbox" name="MI--9-10" value="MI--9-10" id="MI--9-10">
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>

                </div>
                <div class="row form-row">
                    <div class="col-sm-12 col-md-4 col-lg-4 offset-md-4 offset-lg-4">
                        <a class="button primary-button" href="booking-request.php">Reservar</a>
                    </div>
                </div>

            </form>
        </div>
    </article>
</section>
<article class="modal-window container-fluid" id="modal--unavailable-sessions">
    
    <div class="modal-content container">
            <div class="close  js-modal--close">
                <i class="icon ion-md-close"></i>
            </div>
        
        <div class="row modal--td">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <h3>Ya reservaste 5 sesiones</h3>
                <p>No puedes agregar una reservación más porque has excedido el límite por semana.</p>
            </div>
            <div class="col-sm-12 col-md-4 col-lg-4">
                <a class="button primary-button" href="#">Aceptar</a>
            </div>
        </div>

    </div>
</article>
<article class="modal--window container-fluid" id="modal--booking-limit" style="display:none;">
    
    <div class="modal-content container">
            <div class="close  js-modal--close">
                <i class="icon ion-md-close"></i>
            </div>
        
        <div class="row modal--td">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <h3>No cuentas con sesiones disponibles</h3>
                <p>Adquiere un paquete para seguir disfrutando de las instalaciones.</p>
            </div>
            <div class="col-sm-12 col-md-4 col-lg-4">
                <a class="button primary-button" href="plan-selection.php">Reservar</a>
            </div>
        </div>

    </div>
</article>