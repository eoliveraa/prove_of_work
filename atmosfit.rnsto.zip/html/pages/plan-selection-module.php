    <section class="plan-selection container">
        <h4>Paquetes de sesiones</h4>
        <p>Compra una sesión o un paquete para facilitar tu reservación.</p>
        <h5>Sesiones</h5>
        <div class="plan-selection-slider">
            <div class="item">
                <h4>1 sesión</h4>
                <div class="price-label">$270</div>
                <p class="vigencia" href="#">Vigencia 10 días</p>
                <a class="button primary-button" href="iniciar-sesion.php">Comprar</a>
            </div>
            <div class="item">
                <h4>5 sesiones</h4>
                <div class="price-label">$1,250</div>
                <p class="vigencia" href="#">Vigencia 25 días</p>
                <a class="button primary-button" href="iniciar-sesion.php">Comprar</a>
            </div>
            <div class="item">
                <h4>10 sesiones</h4>
                <div class="price-label">$2,400</div>
                <p class="vigencia" href="#">Vigencia 45 días</p>
                <a class="button primary-button" href="iniciar-sesion.php">Comprar</a>
            </div>
        </div>
    </section>
    <section class="plan-selection container">
        <h4>O elige una membresía</h4>
        <h5>Sesiones</h5>
        <div class="plan-selection-membership row">
            <div class="item col-sm-12 col-md-4 col-lg-4">
                <h4>Plan semestral</h4>
                <div class="price-label">$10,500</div>
                <ul>
                    <li>Usos ilimitados</li>
                    <li>Cupón GNC</li>
                    <li>Ahorra hasta 40%</li>
                </ul>
                <a class="button primary-button" href="iniciar-sesion.php">Comprar</a>
            </div>
            <div class="item col-sm-12 col-md-4 col-lg-4">
                <h4>Plan anual</h4>
                <div class="price-label">$15,500</div>
                <ul>
                    <li>Usos ilimitados</li>
                    <li>Ahorra hasta 60%</li>
                    <li>Playera de ATMOSFIT</li>
                </ul>
                <a class="button primary-button" href="iniciar-sesion.php">Comprar</a>
            </div>
        </div>
    </section>