<?php include "header.php"; ?>

<!-- YOUR HTML HERE -->
    <section class="internal-pages container">
        <div class="row">
            <div class="col-sm-12 col-md-6 col-lg-6 offset-md-3 offset-lg-3">
                <div class="go-back">
                    <a href="index.php"><i class="fa fa-chevron-left"></i></a>
                </div>
                <h1>Registro</h1>
                <article class="social-login buttons">
                    <div id="gSignInWrapper">
                        <div id="googleAuth-btn" class="customGPlusSignIn">
                            <div class="g-btn--content">
                                <span class="icon"></span>
                                <span class="buttonText">Google</span>
                            </div>
                        </div>
                    </div>
                    <div id="name"></div>
                    <script>startApp();</script>
                </article>
            
                <article class="social-login buttons">
                    <div class="fb-login-button" data-width="" data-size="large" data-button-type="continue_with" data-auto-logout-link="false" data-use-continue-as="true"></div>
                </article>
                <article class="classic-log-in">
                    <h5>Datos complementarios</h5>
                    <form class="basic-form">
                            <h4>Datos personales</h4>
                            <div class="input-group ">
                                <label>Nombre (s)</label>
                                <input class="main-input" type="text">
                            </div>
                            <div class="input-group">
                                <label>Apellidos</label>
                                <input class="main-input" type="text">
                            </div>
                            <div class="input-group">
                                <label>Fecha de nacimiento</label>
                                <input class="main-input" type="date">
                            </div>
                        
                        
                        <div class="input-group">
                            <label>Género</label>
                            <div class="radio-label">Mujer</div>
                            <input class="main-input" type="radio" name="gender" value="Mujer">
                            <div class="radio-label">Hombre</div>
                            <input class="main-input" type="radio" name="gender" value="Hombre">
                            <div class="radio-label">Prefiero no responder</div>
                            <input class="main-input" type="radio" name="gender" value="No-declarado">
                        </div>
                        <div class="input-group">
                            <label>Deportes que practicas</label>
                            <select>
                                <option>Atletismo</option>
                                <option>Básquetbol</option>
                                <option>Ciclismo</option>
                                <option>Deporte en equipo (Futbol, basquet bol)</option>
                                <option>Montañismo</option>
                                <option>Trail Run</option>
                                <option>Triatlón</option>                                
                                <option>Otros</option>
                            </select>
                        </div>
                        <div class="input-group">
                            <label>¿Perteneces a un club o grupo deportivo?</label>
                            <div class="radio-label">Sí</div>
                            <input class="main-input" type="radio" name="sport-club" value="Si">
                            <div class="radio-label">No</div>
                            <input class="main-input" type="radio" name="sport-club" value="No">
                            <label>Indica el nombre</label>
                            <input class="main-input" type="text">
                        </div>
                        <h4>Contacto</h4>
                        <div class="input-group">
                            <label>Teléfono (10 dígitos)</label>
                            <input class="main-input" type="tel" placeholder="Ej: 8183123456">
                        </div>
                        <div class="input-group ">
                            <label>Correo electrónico</label>
                            <input class="main-input" type="email">
                        </div>
                        <div class="input-group">
                            <label>Código postal</label>
                            <input class="main-input" type="number">
                        </div>
                        <h4>Contacto de emergencia</h4>
                        <div class="input-group">
                            <label>Nombre completo</label>
                            <input class="main-input" type="text">
                        </div>
                        <div class="input-group">
                            <label>Teléfono (10 dígitos)</label>
                            <input class="main-input" type="tel" placeholder="Ej: 8183123456">
                        </div>
                        <h4>Facturación</h4>
                        <div class="input-group" >
                            <label>Requiero factura</label>
                            <input class="main-input" type="checkbox" name="invoice-request" value="invoice-request" id="checkInvoice" onclick="invoiceFunction()">
                        </div>
                        <div id="invoiceData" style="display:none">
                            <div class="input-group invoice-data">
                                <label>RFC</label>
                                <input class="main-input" type="text" maxlenght="13">
                            </div>
                            <div class="input-group invoice-data">
                                <label>Razón Social</label>
                                <input class="main-input" type="text">
                            </div>
                            <div class="input-group invoice-data">
                                <label>Uso de CFDI</label>
                                <select>
                                    <option>Gastos en general</option>
                                    <option>Otros</option>
                                </select>
                            </div>
                        </div>
                        <div class="input-group" >
                            <label>Acepto que leí los <a href="terminos-y-condiciones.php" target="_blank">términos y condiciones</a> </label>
                            <input class="main-input" type="checkbox" name="checkTerms" value="TerminosAceptados" id="checkTerms" onclick="termsFunction()"> 
                        </div>
                        <a class="button primary-button terms-validation" href="pagar.php" id="submitTerms">Continuar</a>
                    </form>
                </article>
            </div>
        </div>
    </section>


<?php include "footer.php"; ?>
