<?php include "header.php"; ?>

<!-- YOUR HTML HERE -->
<section class="internal-pages container">
        <!--div class="go-back">
            <a href="index.php"><i class="fa fa-chevron-left"></i></a>
        </div-->
        
        <article class="row">
            <div class="col-sm-12 col-md-8 col-lg-8 offset-md-2 offset-lg-2">
                <h1>TERMINOS Y CONDICIONES ATMOSFIT</h1>
            <p>Lea los Términos y Condiciones antes de utilizar el sitio web (el "Sitio"). En cada ocasión en la que usted utilice el sitio web de Atmos Hypoxico, S.A. de C.V., y sus subsidiarias y/o afiliadas (colectivamente, "Atmosfit "), su uso indica su total aceptación y su acuerdo con los presentes Términos y Condiciones. </p>
            <p>Usted reconoce, entiende y acepta que los presentes Términos y Condiciones de uso constituyen un acuerdo legamente vinculante entre usted y Atmosfit.</p>
            <p>Atmosfit ofrece los servicios de asesoría, acondicionamiento y entrenamiento físico de alto rendimiento. Los servicios de Atmosfit podrán complementarse con cámaras de Hypóxico y métodos de simulación de altura. </p>
            <p>Se entiende por Usuario, toda persona mayor de edad en pleno uso de sus facultades y ejercicio de sus facultades para contratar y contraer toda clase de obligaciones que utilice el Sitio. </p>
            <p>El Usuario acepta brindar los datos de su tarjeta de crédito, o cualquier otro medio de pago electrónico aprobado por Atmosfit y explícitamente autoriza a Atmosfit a realizar los cargos correspondientes por los Servicios. </p>
            <h3>Registro</h3>
            <h4>Para utilizar los Servicios, el Usuario deberá:</h4>
            <ol>
                <li>Ingresar al Sitio (www.atmosfit.com) y crear una Cuenta de acuerdo con las instrucciones proporcionadas.
                    El Usuario deberá de proporcionar los datos solicitados y aceptar los presentes Términos y Condiciones y el <a href="privacidad.php">Aviso de Privacidad</a>. Los datos personales recabados serán tratados bajo las disposiciones de la Ley Federal de Protección de Datos Personales en Posesión de los Particulares.
Atmosfit podrá solicitar información adicional en cualquier momento.</li>
                <li>Una vez que se haya completado la información solicitada, se entiende que el Usuario otorga su consentimiento para contratar.</li>
                <li>Después de completar el registro, Atmosfit le proporcionará una cuenta a la cual podrá acceder con su usuario y contraseña.</li>
                <li>Este usuario y contraseña es individual, exclusivo, privado y se utilizará para contratar los Servicios a través de su cuenta.</li>
                <li>Usted es el único responsable de la actividad que ocurra en su cuenta y de mantener la confidencialidad de la contraseña. Es su obligación notificar inmediatamente a Atmosfit sobre cualquier irregularidad, uso no autorizado o violación de seguridad de su cuenta.</li>
                <li>Usted reconoce y se obliga a cualquier contratación de servicio, consentimiento o actividad realizado desde su cuenta con usuario y contraseña. Atmosfit no será responsable del uso inadecuado y cargos que se produzcan desde su cuenta.</li>
                <li>Usted se obliga a no transmitir, ceder o compartir su nombre de usuario y/o contraseña. El Usuario no podrá ceder o transmitir los derechos derivados de su cuenta a ningún tercero, por lo que cualquier transmisión o cesión llevaba a cabo en contra de esta disposición  no será reconocida y se le negará el acceso al cesionario. </li>
            </ol>
            <h3>Planes</h3>
            <p>Atmosfit pone a disposición del Usuario diversos planes para el uso de los servicios. Los planes de uso podrán variar de acuerdo con la información proporcionada en la página web.</p>
            <h3>Horarios de Servicio</h3>
            <p>Atmosfit estará abierto y en la disponibilidad de acuerdo al Calendario establecido en el Sitio.</p>
            <p>Atmosfit se reserva el derecho a cerrar las instalaciones generales o áreas específicas o restringir los horarios en días festivos o en días en que el mantenimiento de las instalaciones lo requiera, para lo cual se le avisará a el Usuario con la mayor anticipación posible.</p>
            <p>En los casos en los cuales Atmosfit se vea en la necesidad de suspender o cancelar los servicios por causas de fuerza mayor o caso fortuito, no se reembolsará el pago realizado.</p>
            <h3>Reserva de equipo </h3>      
                <h4>El procedimiento para reservar un equipo es el siguiente:</h4>
                <ol>
                    <li>Ingresar con su usuario y contraseña a su cuenta en el sitio web www.atmosfit.com </li>
                    <li>Ingresar al apartado “RESERVAR EQUIPO” en donde aparecerán los horarios y los equipos disponibles para reservar.</li>
                    <li>Una vez que haya visto las opciones y la disponibilidad para reservar el equipo, podrá reservar y se integrará a la lista de asistentes en el horario determinado.</li>
                    <li>Una vez que Usted haya hecho la reservación, está confirmado su asistencia y está autorizando a Atmos a realizar el cargo a la tarjeta de crédito que Usted vinculó con su cuenta o a tomar alguna sesión del Paquete que haya adquirido.</li>
                    <li>Una vez que su pago haya sido autorizado, recibirá la confirmación de su Reserva.</li>
                    <li>Usted podrá cancelar su asistencia a la Sesión únicamente hasta 120 minutos antes del comienzo de la Sesión. </li>
                </ol>
                <h3>Pago</h3>
                <p>Atmosfit presta un servicio y cobra una tarifa por dicho servicio. Usted autoriza a Atmosfit a realizar los cargos seleccionados a través de su tarjeta de crédito o medio de pagos en línea. </p>
                <p>Atmosfit comunicará sus tarifas a través de su sitio web y podrá modificar dichas tarifas de tiempo en tiempo y bajo su total discreción y sin previo aviso.</p>
                <p>Atmosfit podrá utilizar procesadores de pagos de terceros para vincular su cuenta con su tarjeta de crédito o el medio de pago online seleccionado. La relación con el procesador de pagos y el emisor de su tarjeta de crédito estará sujeta a sus Términos y Condiciones y su Aviso de Privacidad.</p>
                <p>Algunos productos y servicios ofertados en el sitio web de Atmosfit, podrán estar sujetos además de los presentes términos y condiciones, a condiciones particulares de venta, los cuales podrán ser consultados por el Usuario junto con la descripción del producto.</p>
                <p>El Usuario, previo a la compra del servicio, debe aceptar las condiciones particulares de venta, siendo el caso que los presente términos y condiciones generales podrán verse adicionados, limitados o modificados en función de las correspondientes condiciones particulares de venta del producto de que se trate, en caso de conflicto o contradicción en los presentes términos y condiciones y las condiciones particulares de venta, estas últimas prevalecerán sobre las primeras, en consecuencia el Usuario debe leer con atención además de los presente términos y condiciones, las condiciones particulares de venta, las cuales se entenderán aceptadas en el momento que el suscriptor proceda a la compra del producto.</p>
                <h3>Indemnización</h3>
                <p>El Usuario se compromete a indemnizar a Atmosfit, sus socios, empleados, funcionarios, proveedores, vendedores, afiliados, asesores y colaboradores de cualquier acción, demanda o reclamación (incluso por honorarios de abogados y de costas judiciales) que surjan de cualquier incumplimiento a los presentes Términos y Condiciones.</p>
                <h3>Responsabilidad de uso del Sitio</h3>
                <p>Atmosfit no será responsable por ningún fallo, daño, perjuicio o pérdida que sufra el Usuario causado por fallas en el sistema, en el servidor o en Internet, tampoco será responsable por cualquier virus que pudiera afectar el equipo del Usuario por el acceso y/o uso del Sitio.</p>
                <p>Los Usuarios no podrán imputarle responsabilidad alguna ni exigirle indemnizaciones, en virtud perjuicios causados por dificultades técnicas o fallas en el sistema o en Internet. Atmosfit no garantiza el acceso y el uso ininterrumpido del Sitio y de los Servicios.</p>
                <p>El Usuario reconoce que la página web podrá no estar disponible debido a actualizaciones, mantenimiento, dificultades técnicas o fallas en la red, o por cualquier otra circunstancia. </p>
                <p>El Usuario se compromete a no violar o intentar violar la seguridad del Sitio. Está prohibido y es considerado una violación a los Términos y Condiciones de Uso, manipular o intentar manipular cualquier parte del sitio, proporcionar información falsa o inexacta, alterar su identidad o realizar actividades fraudulentas.</p>
                <h3>Responsabilidad de Uso de las Instalaciones</h3>
                <p>El Usuario se obliga a utilizar el equipo, las instalaciones y los demás bienes de Atmosfit, de acuerdo a la naturaleza y las indicaciones correspondientes, siguiendo en todo momento las indicaciones del personal de Atmosfit; por lo tanto, el uso de todas las instalaciones y bienes es responsabilidad única y exclusiva del Usuario, asumiendo la responsabilidad por los daños y perjuicios que sufrieren en sus personas y bienes o que causen a terceros en sus personas y bienes, derivados del mal uso que le den a los mismos, liberando a Atmosfit de cualquier responsabilidad por los daños y perjuicios causados.</p>
                <h3>Responsabilidad de Autorización Médica</h3>
                <p>Atmosfit requiere que el Usuario consulte con su médico y obtenga su autorización de uso antes de hacer uso de cualquiera de nuestros servicios. Atmosfit no es un centro médico y no cuenta con experiencia ni facultades para diagnosticar, examinar o tratar condiciones médicas de ningún tipo, ni determinar el efecto de ningún ejercicio específico. El Usuario no deberá de menospreciar o sustituir una opinión médica por la información contenida en el Sitio.</p>
                <h3>Reconocimiento de Riesgo y Renuncia de Responsabilidad</h3>
                <h4>El Usuario reconoce:</h4>
                <ol>
                    <li>Que no cuenta con ninguna condición ni impedimento físico ni mental que lo pongan en peligro durante los servicios de Atmosfit.</li>
                    <li>Que cuenta con autorización médica para utilizar los servicios de Atmosift.</li>
                    <li>Que en caso de cansancio extremo o algún malestar físico, deberá de suspender el uso de los servicios.</li>
                    <li>Que utiliza los servicios de Atmosfit bajo su propia voluntad y con pleno conocimiento de sus riesgos y consecuencias. </li>
                    <li>Que algunos de los riesgos del Uso de los Servicios de Atmosfit podrían ser, entre otros y sin limitación: mareos, vómito, perdida de presión, lesiones menores y mayores, insuficiencias o ataques cardiacos, parálisis o incluso la muerte, por lo que el Usuario expresamente reconoce los riesgos no pueden ser disminuidos por Atmosift y decide aceptarlos bajo su propia y exclusiva responsabilidad. </li>
                    <li>Que firma y acepta voluntariamente el presente documento y que la vigencia de dicha aceptación será indefinida. </li>
                </ol>
                <p>El Usuario, en el presente acto, libera a Atmosfit y a cualquiera de sus filiales, subsidiarias, asociados, socios, accionistas, directivos, empleados, consultores, funcionarios, agentes, apoderados y representantes de cualquier y toda reclamación, responsabilidad, daños y perjuicios, costas, demanda, procedimientos y/o acción legal que surja como consecuencia del uso de los servicios y/o instalaciones de Atmosfit. </p>
                <h3>Indicaciones</h3>
                <p>El Usuario reconoce que el personal de Atmosfit se encuentra capacitado para prestar los Servicios y acatará cualquier indicación que el personal le señale, especialmente la negativa a que el Usuario continúe utilizando los Servicios cuando a juicio exclusivo del personal el Usuario se encuentre en riesgo.</p>
                <p>El usuario reconoce que Atmosfit no será responsable por la pérdida, robo, extravío, daño o menoscabo de cualquier objeto o bien mueble, incluyendo bicicletas, artículos electrónicos dejados en las instalaciones. </p>
                <h3>Vigencia</h3>
                <p>Los presentes Términos y Condiciones se celebran por una duración indefinida. No obstante, Atmosfit está autorizado para dar por terminada o suspender la prestación de los servicios en cualquier momento y con efecto inmediato en caso de que el Usuario, a juicio de Atmosfit, realice uso indebido del Sitio, del Equipo o que incumpla cualquiera de las cláusulas de los presentes Términos y Condiciones. Dicha suspensión y/o terminación de ninguna forma podrá originar al Usuario el derecho a reclamar los daños y/o perjuicios que pudieran producir.</p>
                <h3>Modificaciones </h3>
                <p>Bajo los presentes Términos y Condiciones, Atmosfit se reserva el derecho de modificar o de revocar el derecho de uso en cualquier momento y por cualquier razón, sin penalidad alguna.</p>
                <h3>Propiedad Intelectual </h3>
                <p>Ambas partes reconocen que ATMOSFIT es la única propietaria de los derechos de propiedad intelectual, ya sean registrados o no registrados, en el sitio web www.atmosfit.com incluyendo, pero no limitado, a: proyectos, software, código fuente, gráficos, fotografías, videos, imágenes, músicas, sonido, textos, logos, marcas, nombres de dominio, nombres comerciales y datos incluidos en la sitio Web www.atmosfit.com. La totalidad del contenido de este sitio también está protegido por derechos de autor como un trabajo colectivo bajo las leyes de derechos de autor en México y las convenciones internacionales.</p>
                <p>Está prohibida la copia, reproducción, adaptación, modificación, distribución, comercialización, licencia, envío, divulgación, comunicación pública y/o cualquier otra acción que genere una infracción de la legislación mexicana o internacional vigente en materia de propiedad intelectual y/o industrial, así como el uso de los contenidos del Sitio sin previa autorización expresa y por escrito de Atmosfit.</p>
                <p>En caso de que el Usuario transmita a Atmosfit cualquier información, programas, aplicaciones, software o en general cualquier material que requiera ser licenciado a través del Sitio Web www.atmosfit.com.mx, el Usuario otorga en este acto a Atmosfit una licencia perpetua, universal, gratuita, no exclusiva, mundial y libre de regalías, que incluye los derechos de sublicenciar, vender, reproducir, distribuir, transmitir, crear trabajos derivados, exhibirlos y ejecutarlos públicamente.</p>
                <p>Lo establecido en el párrafo anterior se aplicará igualmente a cualquier otra información que el Usuario envíe o transmita a Atmosfit incluyendo, sin limitación alguna, preguntas, críticas, comentarios y sugerencias para renovar o mejorar el Sitio, ya sea que éstas hayan sido incluidas en cualquier espacio de la página señalada o en virtud de otros medios o modos de transmisión conocidos o que sean desarrollados en el futuro. Además, cuando el Usuario remite comentarios o críticas al Sitio, también concede a Atmosfit el derecho a utilizar el nombre que el Usuario envíe, en el marco de dicha revisión, comentario, o cualquier otro contenido.</p>
                <p>Por lo anterior, el Usuario renuncia expresamente en este acto a llevar a cabo cualquier acción, demanda o reclamación en contra de Atmosfit sus afiliados o proveedores por cualquier actual o eventual violación de cualquier derecho de autor o propiedad intelectual derivado de la información, programas, aplicaciones, software, ideas y demás material que el propio Usuario envíe al sitio web www.atmosfit.com.mx.</p>
                <p>En caso de considerar que cualquier contenido publicado en el Sitio Web es violatorio de derechos de propiedad intelectual o industrial, el Usuario podrá realizar una notificación contactando el centro de Atención al Cliente de Atmosfit. El Usuario tendrá que indicar: i) datos personales verídicos (nombre, dirección, número de teléfono y dirección de correo electrónico del reclamante); ii) firma autógrafa con los datos personales del titular de los derechos de propiedad intelectual; iii) indicación precisa y completa del (los) contenido(s) protegido(s) mediante los derechos de propiedad intelectual supuestamente infringidos, así como la localización de dichas violaciones en el sitio web referido; iv) declaración expresa y clara de que la introducción del (los) contenido(s) indicado(s) se ha realizado sin el consentimiento del titular de los derechos de propiedad intelectual supuestamente infringidos; v) declaración expresa, clara y bajo la responsabilidad del reclamante de que la información proporcionada en la notificación es exacta y de que la introducción del(los) contenido(s) constituye una violación de dichos derechos.</p>
                <p>Durante el uso de este Sitio web, el Usuario acepta recibir correos electrónicos promocionales del sitio www.Atmosfit.mx., no obstante, posteriormente, el Usuario podrá optar por no recibir tales correos promocionales seleccionando la opción correspondiente en la parte inferior de cualquier correo electrónico promocional.</p>
                <p>Los datos proporcionados por el cliente son protegidos de acuerdo con nuestro aviso de privacidad, publicado en www.atmosfit.com/avisodeprivacidad</p>
                <p>Como condición de su uso del Sitio, usted acepta indemnizar y eximir a Atmosfit y sus Filiales/Subsidiarias de todos los reclamos, pérdidas, responsabilidad, costos y gastos (incluidos, entre otros, los honorarios de los abogados), según se incurran, que surjan de su uso del Sitio o servicios relacionados o de su violación de estos Términos y condiciones de uso.</p>
                <h4>Usted declara y garantiza que: </h4>
                <ol>
                    <li>Tiene plena autoridad y todos los derechos necesarios para celebrar y cumplir plenamente todas sus obligaciones de conformidad con estos Términos y condiciones de uso; </li>
                    <li>Usted no ha celebrado ningún acuerdo ni realizará ningún acto que pueda contravenir los propósitos y / o efectos de estos Términos y condiciones de uso; y </li>
                    <li>No eliminará ningún Contenido.</li>
                </ol>
                <h3>Legislación Aplicable y Tribunales Competentes</h3>
                <p>Para la interpretación, cumplimiento o ejecución de lo pactado en el presente Contrato, ambas partes acuerdan expresamente someterse a las Leyes vigentes en el Estado de Nuevo León y al fuero de los Tribunales cuya jurisdicción comprende al Municipio de Monterrey, Nuevo León, renunciando expresamente a cualquier otro fuero que por razón de sus domicilios presentes o futuros o por cualquier otra causa pudiera corresponderles.</p>
                <h3>Acuerdo Total</h3>
                <p>Los Presentes Términos y Condiciones de Uso constituyen un acuerdo total y único entre el Usuario y Atmosfit.</p>
                <p>Fecha: Septiembre de 2019 </p>

            </div>
        </article>
    </section>

<?php include "footer.php"; ?>
