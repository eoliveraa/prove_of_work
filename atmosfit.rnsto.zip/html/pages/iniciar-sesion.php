<?php include "header.php"; ?>

<!-- YOUR HTML HERE -->
    <section class="internal-pages container">
        <div class="row">
            <div class="col-sm-12 col-md-6 col-lg-6 offset-md-3 offset-lg-3">
                <div class="go-back">
                    <a href="index.php"><i class="fa fa-chevron-left"></i></a>
                </div>
                <h1>Iniciar sesión</h1>
                <article class="social-login buttons">
                    <div id="gSignInWrapper">
                        <div id="googleAuth-btn" class="customGPlusSignIn">
                            <div class="g-btn--content">
                                <span class="icon"></span>
                                <span class="buttonText">Google</span>
                            </div>
                        </div>
                    </div>
                    <div id="name"></div>
                    <script>startApp();</script>
                </article>
                <article class="social-login buttons">
                    <div class="fb-login-button" data-width="" data-size="large" data-button-type="continue_with" data-auto-logout-link="false" data-use-continue-as="true"></div>
                </article>
                <article class="classic-log-in">
                    <h5>O con tu correo electrónico</h5>
                    <form class="basic-form">
                        <label>Correo electrónico</label>
                        <input class="main-input" type="email">
                        <label>Contraseña</label>
                        <input class="main-input" type="password">
                        <a href="#">Olvidé mi contraseña</a>
                        <a class="button primary-button" href="pagar.php">Iniciar sesión</a>
                        <a href="registro.php">¿Aún no formas parte de Atmosfit?</a>
                    </form>
                </article>
            </div>
        </div>
    </section>


<?php include "footer.php"; ?>
