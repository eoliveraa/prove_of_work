<?php include "header.php"; ?>

<!-- YOUR HTML HERE -->
    <section class="internal-pages container">
        <div class="row">
            <div class="col-sm-12 col-md-6 col-lg-6 offset-md-3 offset-lg-3">
                <div class="go-back">
                    <a href="index.php"><i class="fa fa-chevron-left"></i></a>
                </div>
                <h1>Pagar sesiones</h1>
                <h2>Tu selección</h2>
                <article class="plan-selection shopping-resume">
                    <div class="item">
                        <h4>1 sesión</h4>
                        <div class="price-label">$270</div>
                        <div class="vigencia" href="#">Vigencia 10 días</div>
                        <a href="#">Cambiar</a>
                    </div>
                </article>
                <h2>Datos de pago</h2>
                <h5>*Por tu seguridad, no almacenamos los datos de tu tarjeta</h5>
            </div>
        </div>
    </section>
    <section>
        <div class="row">
            <div class="col-sm-12 col-md-6 col-lg-6 offset-md-3 offset-lg-3">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="tab--credit-card" data-toggle="tab" href="#pay--credit-card" role="tab" aria-controls="par--credit-card" aria-selected="true">Tarjeta de crédito</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="tab--paypal" data-toggle="tab" href="#pay--paypal" role="tab" aria-controls="pay--paypal" aria-selected="false"><i class="fa fa-paypal"></i> Paypal</a>
                    </li>
                </ul>
                <div class="tab-content container" id="myTabContent">
                    <div class="tab-pane fade show active" id="pay--credit-card" role="tabpanel" aria-labelledby="pay--credit-card">
                        <form class="basic-form">
                            <h4>Datos de tarjeta</h4>
                            <div class="input-group col-sm-12">
                                <label>Número de tarjeta</label>
                                <input type="number" class="main-input" maxlength="16">
                            </div>
                            <div class="input-group">
                                <label>Vigencia</label>
                                <select class="vigencia" name="vigencia-mes">
                                    <option value="01" selected >(01) Enero</option>
                                    <option value="02">(02) Febrero</option>
                                    <option value="03">(03) Marzo</option>
                                    <option value="04">(04) Abril</option>
                                    <option value="05">(05) Mayo</option>
                                    <option value="06">(06) Junio</option>
                                    <option value="07">(07) Julio</option>
                                    <option value="08">(08) Agosto</option>
                                    <option value="09">(09) Septiembre</option>
                                    <option value="10">(10) Octubre</option>
                                    <option value="11">(11) Noviembre</option>
                                    <option value="12">(12) Diciembre</option>
                                </select>
                                <select class="vigencia" name="vigencia-ano">
                                    <option selected value="2019">2019</option>
                                    <option value="2020">2020</option>
                                    <option value="2021">2021</option>
                                    <option value="2022">2022</option>
                                    <option value="2023">2023</option>
                                    <option value="2024">2024</option>
                                    <option value="2025">2025</option>
                                    <option value="2026">2026</option>
                                    <option value="2027">2027</option>
                                    <option value="2028">2028</option>
                                </select>
                            </div>
                            <div class="input-group col-6">
                                <label>CVV</label>
                                <input class="main-input" type="number" maxlength="4">
                            </div>
                            <div class="input-group col-sm-12">
                                <label>Nombre de titular de tarjeta</label>
                                <input class="main-input" type="text">
                            </div>
                            <div class="input-group" >
                                <label>Acepto que leí los <a href="terminos-y-condiciones.php" target="_blank">términos y condiciones</a> y el <a href="privacidad.php" target="_blank">aviso de privacidad</a> </label>
                                <input class="main-input" type="checkbox" name="checkTerms" value="TerminosYAvisoAceptados" id="checkTerms" onclick="termsFunction()"> 
                            </div>
                            <a class="button primary-button terms-validation" href="perfil.php" id="submitTerms">Continuar</a>
                        </form>
                    </div>
                    <div class="tab-pane fade" id="pay--paypal" role="tabpanel" aria-labelledby="pay--paypal">
                        PAYPAL
                    </div>
                </div>
            </div>
        </div>
    </section>
        


<?php include "footer.php"; ?>
