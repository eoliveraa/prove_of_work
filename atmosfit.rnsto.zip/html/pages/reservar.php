<?php include "header.php"; ?>

<!-- YOUR HTML HERE -->
    <section class="internal-pages container">
        <div class="row">
            <div class="col-12">
                <div class="go-back">
                    <a href="index.php"><i class="fa fa-chevron-left"></i></a>
                </div>
                <h1>Reservar</h1>
            </div>
        </div>
    </section>
    <?php include "booking-module.php"; ?>
    

<?php include "footer.php"; ?>
